var w = 625, h = 400;
var game = new Phaser.Game( w, h, Phaser.CANVAS, '');

var basicGame = function(){

}