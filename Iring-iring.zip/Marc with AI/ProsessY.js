var sukat = 0.3;
var currentSpeed = 0;
var upBtn;
var kananBtn;
var kaliwaBtn;
var abante = false;
var kanan = false;
var kaliwa = false;
var nextAbante = 0;
var stateText;
var tapos;
var panyo;
var panyos;
var bomb;
var bombs;
var GameState = function(game) {
};
function createFlags(time){
    setInterval(function(){
        for (var r = 0; r < 50; r++)
    {
        var panyos = panyo.create(game.world.randomX, game.world.randomY, 'panyo');
    }
    },20000);
}

function addBombs(bombs){
        bomb = game.add.group();
        // game.physics.arcade.enable(flags);
        bomb.enableBody = true;
            for (var b = 0; b < 100; b++)
    {
        var bombs = bomb.create(game.world.randomX, game.world.randomY, 'bomb');
    }
}

// Load images and sounds
GameState.prototype.preload = function() {
    this.game.load.image('players', 'assets/gfx/player.png');
    game.load.image('player', 'assets/images/kalaro.png');
    this.game.load.image('flag', 'assets/gfx/flag.png');
    this.game.load.image('panyo', 'assets/gfx/panyo.png');
    this.game.load.image('bomb', 'assets/gfx/bomb.png');
    this.game.load.image('pbg','assets/images/sky.png');
    this.game.load.spritesheet('taya', 'assets/images/tayaN.png',122,175);
    this.game.load.spritesheet('UpButton','assets/images/UpBtn.png',89,58);
    this.game.load.image('lupa', 'assets/images/Land.png');
    game.load.spritesheet('pauseButton','assets/images/pause2.png',31,33);
};

// Setup the example
GameState.prototype.create = function() {

    game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
        game.scale.forcePortrait = true;
        game.scale.forceLandscape = false;
        game.scale.pageAlignVertically = true;
        game.scale.pageAlignHorizontally = true;
        game.scale.setScreenSize = true;
        game.scale.refresh();
    // Set stage background color
    game.world.setBounds(-1000, -1000, 2000, 2000);
    this.game.stage.backgroundColor = 0x4488cc;

    land = game.add.tileSprite(0, 0, 620, 400, 'lupa');
        land.fixedToCamera = true;



        game.time.events.add(2000, addBombs);
            panyo = game.add.group();
        // game.physics.arcade.enable(flags);
        panyo.enableBody = true;
        createFlags(1);
            for (var r = 0; r < 30; r++)
    {
        var panyos = panyo.create(game.world.randomX, game.world.randomY, 'panyo');
    }


        

        

    cursors = game.input.keyboard.createCursorKeys();

    Taya = game.add.sprite(100, 160, 'taya');
        game.physics.enable(Taya, Phaser.Physics.ARCADE);
        Taya.animations.add('move',[0,1,2,3],20,true);
        //game.physics.arcade.enable(Taya);
        //Taya.enableBody = true;
        Taya.anchor.set(0.5);
        Taya.scale.x = sukat;
        Taya.scale.y = sukat;
        Taya.body.immovable = false;
        
        //Taya.body.bounce.setTo(1, 1);
        Taya.angle = game.rnd.angle();
        
        Taya.body.drag.set(0.2);
        Taya.body.maxVelocity.setTo(400, 400);
        Taya.body.collideWorldBounds = true;
        //Taya.fixedToCamera = true;
        game.camera.follow(Taya);
        game.camera.deadzone = new Phaser.Rectangle(100, 100, 100, 100);
        game.camera.focusOnXY(0, 0);

        labelScore = game.add.text(440, 19, "Score: ", {font: '15px Arial', fill: '#ffffff'});  
        labelhi = game.add.text(300, 19, "HI: " +getScore(),{font: '15px Arial', fill: '#ffffff'}); 
        labelScore.fixedToCamera = true;
        labelhi.fixedToCamera = true;

    // Create 5 followers, each one following the one ahead of it
    // The first one will follow the mouse pointer
    var NUMBER_OF_FOLLOWERS = 1;
    for(var i = 0; i < NUMBER_OF_FOLLOWERS; i++) {
        var f = this.game.add.existing(
            new Follower(this.game,
                this.game.width/2 + i * 600,
                this.game.height/2,
                f || Taya /* the previous follower or pointer */
            )
        );
    }

    // Create a target for the second group and
    // move it around the perimeter of the stage.
    // var flag = this.game.add.sprite(50, 50, 'flag');
    // //game.physics.enable(taya, Phaser.Physics.ARCADE);
    // // this.game = taya;
    // // taya.enableBody = true;
    
    // this.game.add.tween(flag)
    //     .to({ x: this.game.width - 50, y: 50 }, 2000, Phaser.Easing.Sinusoidal.InOut)
    //     .to({ x: this.game.width - 50, y: this.game.height - 50 },
    //         1200, Phaser.Easing.Sinusoidal.InOut)
    //     .to({ x: 50, y: this.game.height - 50 }, 2000, Phaser.Easing.Sinusoidal.InOut)
    //     .to({ x: 50, y: 50 }, 1200, Phaser.Easing.Sinusoidal.InOut)
    //     .start()
    //     .loop();

    // Create 5 more followers, each one following the one ahead of it
    // The first one will follow the target
    // for(i = 0; i < NUMBER_OF_FOLLOWERS; i++) {
    //     var f2 = this.game.add.existing(
    //         new Follower(this.game,
    //             this.game.width/2 + i * 32,
    //             this.game.height/2,
    //             f2 || flag /* the previous follower or the flag */
    //         )
    //     );
    // }

    // Simulate a pointer click/tap input at the center of the stage
    // when the example begins running.
    this.game.input.x = this.game.width/2;
    this.game.input.y = this.game.height/2;

    upbtn = game.add.button(500, 330, 'UpButton', null, this, 0, 1, 0, 1);  //game, x, y, key, callback, callbackContext, overFrame, outFrame, downFrame, upFrame
    upbtn.fixedToCamera = true;  //our buttons should stay on the same place  
    upbtn.events.onInputOver.add(function(){abante=true;});
    upbtn.events.onInputOut.add(function(){abante=false;});
    upbtn.events.onInputDown.add(function(){abante=true;});
    upbtn.events.onInputUp.add(function(){abante=false;});

    kananbtn = game.add.button(110, 350, 'UpButton', null, this, 0, 1, 0, 1);  //game, x, y, key, callback, callbackContext, overFrame, outFrame, downFrame, upFrame
    kananbtn.angle = 90;
    kananbtn.anchor.setTo(0.5,0.5);
    kananbtn.scale.x = 0.8;
    kananbtn.scale.y = 0.8;
    kananbtn.fixedToCamera = true;  //our buttons should stay on the same place  
    kananbtn.events.onInputOver.add(function(){kanan=true;});
    kananbtn.events.onInputOut.add(function(){kanan=false;});
    kananbtn.events.onInputDown.add(function(){kanan=true;});
    kananbtn.events.onInputUp.add(function(){kanan=false;});

    kaliwabtn = game.add.button(30, 350, 'UpButton', null, this, 0, 1, 0, 1);  //game, x, y, key, callback, callbackContext, overFrame, outFrame, downFrame, upFrame
    kaliwabtn.angle = -90;
    kaliwabtn.anchor.setTo(0.5,0.5);
    kaliwabtn.scale.x = 0.8;
    kaliwabtn.scale.y = 0.8;
    kaliwabtn.fixedToCamera = true;  //our buttons should stay on the same place  
    kaliwabtn.events.onInputOver.add(function(){kaliwa=true;});
    kaliwabtn.events.onInputOut.add(function(){kaliwa=false;});
    kaliwabtn.events.onInputDown.add(function(){kaliwa=true;});
    kaliwabtn.events.onInputUp.add(function(){kaliwa=false;});

    this.pauseButton = this.game.add.sprite(10, 20, 'pauseButton');
        this.pauseButton.fixedToCamera = true;
        this.pauseButton.scale.x = 0.8;
        this.pauseButton.scale.y = 0.8;
        this.pauseButton.inputEnabled = true;
        this.pauseButton.events.onInputUp.add(function () {
        this.game.paused = true;
  //    var style = {font:'30px Times New Roman',fill : 'white'};
  //    this.text = game.add.text(, "Game is Paused", style);
  //    this.text.fixedToCamera = true;
  //    this.text.anchor.set(0.5, 0.5);
        }, this);
            game.input.onDown.add(function () {
        if (this.game.paused) {
            this.game.paused = false;
            //this.text.destroy();
    }       
}, this);

    
};

// The update() method is called every frame
GameState.prototype.update = function() {
    game.physics.arcade.overlap(panyo,Taya,ScoreNa);
    game.physics.arcade.overlap(bomb,Taya,OverNa);
    game.physics.arcade.overlap(Follower,Taya,Col);
    
    if (kaliwa && !nextAbante) {
       
        Taya.angle -= 4;
    }
    else if (kanan && !nextAbante) {
       
        Taya.angle +=4;
        //player.animations.play('left');

    }
    if (abante && !nextAbante) {
        Taya.animations.play('move');
        currentSpeed = 110;
        
    }
    //     if (cursors.left.isDown)
    // {
    //     Taya.angle -= 4;
    // }
    // else if (cursors.right.isDown)
    // {
    //     Taya.angle += 4;
    // }

    // if (cursors.up.isDown)
    // {
    //     Taya.animations.play('move');
    //     //  The speed we'll travel at
    //     currentSpeed = 110;
    // }
    else
    {
        if (currentSpeed > 0)
        {
            Taya.animations.stop();
            currentSpeed -= 4;
        }
    }

    if (currentSpeed > 0)
    {
        game.physics.arcade.velocityFromRotation(Taya.rotation, currentSpeed,Taya.body.velocity);
    }
        land.tilePosition.x = -game.camera.x;
        land.tilePosition.y = -game.camera.y;

};
function saveScore(score){
    localStorage.setItem("CrazyMarioGameData.com",score);
}

function getScore(){
    return (localStorage.getItem("CrazyMarioGameData.com") == null || localStorage.getItem("CrazyMarioGameData.com") == "")?0:
    localStorage.getItem("CrazyMarioGameData.com");
}
var x = 0;
function ScoreNa(Taya,panyo){
        panyo.kill();
        x = x+1;
    labelScore.text = "Score: "+x;

    if (getScore()<=x){
        saveScore(x);
        labelhi.text = "HI: "+x;
    }
    }
    function OverNa(Taya,bomb){
        bomb.kill();
        Taya.kill();
        pbg = game.add.sprite(0,0,'pbg');
        pbg.fixedToCamera = true;

    tapos = game.add.text(300,130,'',{font:'22px Times New Roman',fill:'white'});
    tapos.anchor.set(0.5);
    tapos.visible = false;
    //tapos.text="Game Over";
    tapos.text="Game Over";
    tapos.visible = true;
    tapos.fixedToCamera = true;

    stateText = game.add.text(300,170,'',{font:'18px Times New Roman',fill:'white'});
    stateText.anchor.set(0.5);
    stateText.visible = false;
    //stateText.text="Game Over";
    stateText.text="Double Tap to Restart";
    stateText.visible = true;
    stateText.fixedToCamera = true;
    game.input.onTap.addOnce(restart,this);
    game._paused = true
    }
    function restart(){
    window.location.href=window.location.href;
    stateText.visible = false;
    tapos.visible = false;

}
    function Col(Taya,f){
       Taya.kill();
    }
// Over:function(f,Taya){
//     Taya.kill();
// },

// Follower constructor
var Follower = function(game, x, y, target) {
    Phaser.Sprite.call(this, game, x, y, 'player');

    // Save the target that this Follower will follow
    // The target is any object with x and y properties
    this.target = target;

    // Set the pivot point for this sprite to the center
    this.anchor.setTo(0.5, 0.5);

    // Enable physics on this object
    this.game.physics.enable(this, Phaser.Physics.ARCADE);

    // Each Follower will record its position history in
    // an array of point objects (objects with x,y members)
    // This will be used to make each Follower follow the
    // same track as its target
    this.history = [];
    this.HISTORY_LENGTH = 5;
    this.scale.set(0.3);

    // Define constants that affect motion
    this.MAX_SPEED = 100; // pixels/second
    this.MIN_DISTANCE = 32; // pixels
};

// Followers are a type of Phaser.Sprite
Follower.prototype = Object.create(Phaser.Sprite.prototype);
Follower.prototype.constructor = Follower;

Follower.prototype.update = function() {
    // Get the target x and y position.
    //
    // This algorithm will follow targets that may or may not have a position
    // history.
    //
    // The targetMoving flag tells this object when its target is moving
    // so that it knows when to move and when to stop.
    
    var t = {};
    var targetMoving = false;
    if (this.target.history !== undefined && this.target.history.length) {
        // This target has a history so go towards that
        t = this.target.history[0];
        if (this.target.body.velocity.x !== 0 ||
            this.target.body.velocity.y !== 0) targetMoving = true;
    } else {
        // This target doesn't have a history defined so just
        // follow its current x and y position
        t.x = this.target.x;
        t.y = this.target.y;

        // Calculate distance to target
        // If the position is far enough way then consider it "moving"
        // so that we can get this Follower to move.
        var distance = this.game.math.distance(this.x, this.y, t.x, t.y);
        if (distance > this.MIN_DISTANCE) targetMoving = true;
    }

    // If the distance > MIN_DISTANCE then move
    if (targetMoving) {
        // Add current position to the end of the history array
        this.history.push({ x: this.x, y: this.y });

        // If the length of the history array is over a certain size
        // then remove the oldest (first) element
        if (this.history.length > this.HISTORY_LENGTH) this.history.shift();

        // Calculate the angle to the target
        var rotation = this.game.math.angleBetween(this.x, this.y, t.x, t.y);

        // Calculate velocity vector based on rotation and this.MAX_SPEED
        this.body.velocity.x = Math.cos(rotation) * this.MAX_SPEED;
        this.body.velocity.y = Math.sin(rotation) * this.MAX_SPEED;
    } else {
        this.body.velocity.setTo(0, 0);
    }
    // if (game.physics.arcade.overlap(this.target,Taya)){
    //     Taya.kill();
    // }
};

var game = new Phaser.Game(600, 400, Phaser.CANVAS, 'game');
game.state.add('game', GameState, true);