
var process = function(){
	"use strict";
	return {
		
		tweenOut: function() {
			moveOutTween = game.add.tween(emoji).to( { y: 50 }, 600, Phaser.Easing.Elastic.In, true);
			moveOutTween.onComplete.add(function() { emoji.kill(); }, this);
			setTimeout(function () {
				fadeOutTween = game.add.tween(emoji).to( { alpha: 0 }, 300, Phaser.Easing.Linear.None, true, 0, 0, false);
			}, 450);
		},

		hitRim: function() {

			backboard.play();
		},

		createBall: function() {

			var xpos;
			if (current_score === 0) {
				xpos = 200;
			} else {
				xpos = 60 + Math.random() * 280;
			}
			spawn.play();
			ball = game.add.sprite(xpos, 547, 'ball');
			game.add.tween(ball.scale).from({x : 0.7, y : 0.7}, 100, Phaser.Easing.Linear.None, true, 0, 0, false);
			game.physics.p2.enable(ball, false);
			ball.body.setCircle(60); // NOTE: Goes from 60 to 36
			ball.launched = false;
			ball.isBelowHoop = false;
		},

		click:function(pointer) {

			var bodies = game.physics.p2.hitTest(pointer.position, [ ball.body ]);
			if (bodies.length) {
				start_location = [pointer.x, pointer.y];
				isDown = true;
				location_interval = setInterval(function () {
					start_location = [pointer.x, pointer.y];
				}.bind(this), 200);
			}
		},

		release:function(pointer) {

			if (isDown) {
				window.clearInterval(location_interval);
				isDown = false;
				end_location = [pointer.x, pointer.y];

				if (end_location[1] < start_location[1]) {
					var slope = [end_location[0] - start_location[0], end_location[1] - start_location[1]];
					var x_traj = -2300 * slope[0] / slope[1];
					this.launch(x_traj);
				}
			}
		},

		launch:function(x_traj) {

			if (ball.launched === false) {
				ball.body.setCircle(36);
				ball.body.setCollisionGroup(collisionGroup);
				current_best_text.text = '';
				current_best_score_text.text = '';
				ball.launched = true;
				game.physics.p2.gravity.y = 3000;
				game.add.tween(ball.scale).to({x : 0.6, y : 0.6}, 500, Phaser.Easing.Linear.None, true, 0, 0, false);
				ball.body.velocity.x = x_traj;
				ball.body.velocity.y = -1750;
				ball.body.rotateRight(x_traj / 3);
				whoosh.play();
			}
		},

	}
}();